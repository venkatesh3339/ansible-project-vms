<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~>1.9.3 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | ~>3.0.2 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.114 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.114 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_bastion"></a> [bastion](#module\_bastion) | git::https://github.com/dojo360/azure-networking//profiles/bastion-host-v2 | v19.1.4 |
| <a name="module_cloud_provider_helper"></a> [cloud\_provider\_helper](#module\_cloud\_provider\_helper) | git::https://github.com/dojo360/cloud-provider-helper | v1.0.56 |
| <a name="module_sa_artifacts"></a> [sa\_artifacts](#module\_sa\_artifacts) | git::https://github.com/dojo360/azure-storage-account//profiles/custom | v19.1.4 |
| <a name="module_sa_data"></a> [sa\_data](#module\_sa\_data) | git::https://github.com/dojo360/azure-storage-account//profiles/custom | v19.1.4 |
| <a name="module_subscription_bootstrap"></a> [subscription\_bootstrap](#module\_subscription\_bootstrap) | ../../modules/subscription-bootstrap | n/a |
| <a name="module_vnet"></a> [vnet](#module\_vnet) | git::https://github.com/dojo360/azure-networking//profiles/virtual-network-v2 | v19.1.4 |

## Resources

| Name | Type |
|------|------|
| [azurerm_log_analytics_workspace.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |
| [azurerm_nat_gateway.nat_gw](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/nat_gateway) | resource |
| [azurerm_nat_gateway_public_ip_prefix_association.nat_gw_pip_prefix_assoc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/nat_gateway_public_ip_prefix_association) | resource |
| [azurerm_network_security_group.private_endpoint_subnet_sg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_private_dns_zone.agentsvc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.azuredatabricks](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.dfs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.monitor](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.ods](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.oms](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_public_ip_prefix.nat_gw_pip_prefix](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip_prefix) | resource |
| [azurerm_resource_group.rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.private_endpoint_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.private_endpoint_storage_sg_assoc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_subnet_address_space"></a> [bastion\_subnet\_address\_space](#input\_bastion\_subnet\_address\_space) | List of IP Address CIDRs for the bastion subnet | `list(string)` | n/a | yes |
| <a name="input_create_subscription_bootstrap"></a> [create\_subscription\_bootstrap](#input\_create\_subscription\_bootstrap) | Whether to create subscription level bootstrap resources. e.g. terraform state storage, ootb role assignments etc. | `bool` | `false` | no |
| <a name="input_developer_resource_group_names"></a> [developer\_resource\_group\_names](#input\_developer\_resource\_group\_names) | List names of resource groups that will be created for individual developers to create their resources in. | `list(string)` | `[]` | no |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | `"centralus"` | no |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | Unique identifier substring for resource names. e.g. dsaas-nonprod-sub, dsaas-prod-sub. (Try to keep it short) | `string` | n/a | yes |
| <a name="input_private_endpoint_subnet_address_space"></a> [private\_endpoint\_subnet\_address\_space](#input\_private\_endpoint\_subnet\_address\_space) | List of IP Address CIDRs for the endpoint subnet | `list(string)` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of existing resource group to create resources in. Used for creating individual developer environments. | `string` | `""` | no |
| <a name="input_sa_artifacts_name_suffix"></a> [sa\_artifacts\_name\_suffix](#input\_sa\_artifacts\_name\_suffix) | Suffix for name of the storage account for artifacts | `string` | n/a | yes |
| <a name="input_sa_data_name"></a> [sa\_data\_name](#input\_sa\_data\_name) | Name of the storage account for data | `string` | n/a | yes |
| <a name="input_sa_data_rg_name"></a> [sa\_data\_rg\_name](#input\_sa\_data\_rg\_name) | Name of the resource group for storage account for data | `string` | `""` | no |
| <a name="input_subscription_type"></a> [subscription\_type](#input\_subscription\_type) | Type of subscription, nonprod/prod | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | tags to apply to all applicable resources | `map(string)` | `{}` | no |
| <a name="input_vnet_address_space"></a> [vnet\_address\_space](#input\_vnet\_address\_space) | List of IP Address CIDRs for the VNet | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_shared"></a> [shared](#output\_shared) | n/a |
<!-- END_TF_DOCS -->