## Testing Terraform Deployment workflow locally via [nektos/act](https://github.com/nektos/act)
1. Create a local copy of [terraform-configuration.yml](../terraform-configuration.yml) called [terraform-configuration.local.yml](../terraform-configuration.local.yml). It is already added to .gitignore.
1. Update it to include configuration for your local git branch.
    E.g.
    ```
    my_local_git_branch:
      applyTerraform: false
      environments:
        - nonprod/shared
        - nonprod/dev
    ```
1. Create `.secrets` file under [.devcontainer](../../.devcontainer/)
1. Add following lines to it and update with appropriate values
    
    ```
    GITHUB_TOKEN=
    GH_TOKEN=
    ARM_CLIENT_SECRET=""
    creds='{
    "clientSecret": "",
    "subscriptionId": "bd2e96c1-fa09-4a7f-a6a1-4f1506acc156",
    "tenantId": "db05faca-c82a-4b9d-b9c5-0f64b6755421",
    "clientId": "bded4388-3793-433b-b35f-87e4abfdb57e"
    }'
    ```
1. [`.secrets`](../../.devcontainer/.secrets) file is already added to [`.gitignore`](../../.devcontainer/.gitignore). Make sure that is indeed the case and Do **NOT** commit it.
1. Update following command as needed and run

    ```
    act \
        --secret-file .devcontainer/.secrets \
        -P uhg-runner=docker.repo1.uhc.com/epl/optum-runner:0.1.0 \
        --var-file .devcontainer/.env \
        --pull=false \
        --container-options=" \
            -v /var/lib/docker/volumes/vsc-remote-containers/_data/dsaas-azure-iac/.github/terraform-configuration.local.yml:/tmp/terraform-configuration.local.yml:ro \
            -v /var/lib/docker/volumes/vsc-remote-containers/_data/dsaas-azure-iac:/workspace:ro \
            -v shared:/shared:rw \
            --user root" \
        -j apply-terraform
    ```
    Notes:
    -P is used to pass custom docker image. Find latest stage/prod images for optum-runner at https://github.com/optum-eeps/epl-arc-config. You may need to find recent branches for stage/prod deployments since main may not reflect current deployments. Look for PROD_IMAGE/STAGE_IMAGE files at the root of the repo.

    First mount in --container-options allows you to use your local terraform configuration for the workflow. You will need to update the source path. Note that it is ReadOnly inside container since we don't expect to modify it in there.

    Second mount is for workspace itself to make sure paths resolve correctly.

    Third mount is for named volume, shared. It allows you to use caches for things like terraform plugins, npm, pip etc. It's writeable to make sure container can cache artifacts into it.

    --user is required to make sure we run container as root which matches with user being used for dev containers which in turn ensure correct permissions for shared volume.

    You could possibly pass `--use-gitignore=false` if you want to leverage terraform and other dependencies that get cached alongside source code. Note that this deviates further from github actions but is sometimes useful to speed things up locally.