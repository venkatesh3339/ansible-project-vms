# dsaas-azure-iac
DSaaS infrastructure as code repository

# Getting Started

## Infrastructure Developer
1. Request membership to following global secure groups for your primary id
    1. `AZU_GHEC_USERS`
    1. `AZU_GHEC_OI_ANALYTICS_USERS`
    1. `GHEC_OI_ANALYTICS_DSAAS_WRITE`
1. Request membership to following global secure groups for your cloud native id
    1. `AZU_DSAAS_NONPROD_INFRASTRUCTURE_DEVELOPER`
1. Follow dev container setup instructions at [.devcontainer/README.md](.devcontainer/README.md)
1. We are creating developer specific resource groups so that each developer can create/destroy their own resources with appropriate permissions.
1. Add resource group for yourself at `module.subscription.developer_resource_group_names` in [terraform/environments/nonprod/shared/main.tf](terraform/environments/nonprod/shared/main.tf). Note that you do not have permission to apply terraform for non-developer environments, so create PR and get it merged so your resource group will get created via CI/CD workflow.
1. Create your own copy of terraform configuration similar to [terraform/environments/nonprod/tushar](terraform/environments/nonprod/tushar)
1. Update values in your configuration so they don't conflict with other developers' configuration.
1. Since you already have right permissions via secure groups you do not need to activate any JIT roles. Just `az login` and selecting nonprod AZU_DSaaS subscription should be sufficient.
1. Because we are using single developer resource group to manage both subscription and logical environment level resources you need to run terraform commands with `-target` switch so you can create subscription level resources first and then logical environment level resources.
`tf apply -target=module.subscription` followed by `tf apply -target=module.logical_environment`
1. For developer resources we are using IP address blocks that are not issued by HCC/OI Transit Hub and as such VNets will not be compliant with firewall requirements. For that reason and to save costs, do not leave resources around. Test your work by creating resources and then destroy them promptly. `tf destroy -target=module.logical_environment` followed by `tf destroy -target=module.subscription`
