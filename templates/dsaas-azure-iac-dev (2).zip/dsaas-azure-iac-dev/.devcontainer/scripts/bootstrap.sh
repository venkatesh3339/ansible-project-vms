#!/bin/bash

# Bootstrap script for setting up things in container instead of in image.

set -e

mkdir -p $TF_PLUGIN_CACHE_DIR

cp /workspace/.devcontainer/scripts/env_setup.sh /root/env_setup.sh

echo "source /root/env_setup.sh" >> "/root/.bashrc"