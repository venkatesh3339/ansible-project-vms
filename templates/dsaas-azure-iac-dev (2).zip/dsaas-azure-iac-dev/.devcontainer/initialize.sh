#!/bin/bash

# Load environment variables from .env files
set -o allexport
source devcontainer.env
source .env
set +o allexport

printenv | sort

# Create shared volume
docker volume create shared

# Check if password files exist already and if they are empty
# Prompt for passwords and save to appropriate files. Make sure files are created with right permissions.
# TODO: DRY
docker run \
    -it \
    --mount type=bind,src=/host_mnt/Users/$USER,dst=/root \
    bash \
    bash -c \
        '[ -s /root/.GITHUB_TOKEN ] \
            && echo "GITHUB_TOKEN already exists." \
            || (echo -n "Enter Github Token:" \
                && read -s Password \
                && echo $Password > /root/.GITHUB_TOKEN \
                && chmod 600 /root/.GITHUB_TOKEN)'

# build image

docker run \
    -e 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' \
    -e DOCKER_BUILDKIT=1 \
    -e BUILDKIT_PROGRESS=plain \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v $localWorkspaceFolder:/workspace \
    -v /host_mnt/Users/$USER/.GITHUB_TOKEN:/root/.GITHUB_TOKEN:ro \
    docker.repo1.uhc.com/docker \
    docker build \
        --secret id=GITHUB_TOKEN,src=/root/.GITHUB_TOKEN \
        --tag dsaas-azure-iac-shell:latest \
        /workspace/.devcontainer