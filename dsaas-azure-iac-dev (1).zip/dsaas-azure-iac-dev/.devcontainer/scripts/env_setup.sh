# !/bin/bash

# Sets up terminal with useful configuration, aliases and functions

# Environment variables
export GITHUB_TOKEN=$(cat /run/secrets/github_token)

# Set up git completion
source /usr/share/bash-completion/completions/git

# Set up git prompt
if [ -f "/root/.bash-git-prompt/gitprompt.sh" ]; then
    GIT_PROMPT_ONLY_IN_REPO=1
    source /root/.bash-git-prompt/gitprompt.sh
fi

# Aliases
alias tf='terraform'

# Set up aws cli tab completion
source /etc/bash_completion.d/azure-cli

# Retain bash history. The file is added to .gitignore to prevent commit.
export PROMPT_COMMAND='history -a'
export HISTFILE=/workspace/.devcontainer/.bash_history

# Set JAVE_HOME
ARCH=$([[ $(uname -m) = "aarch64" ]] && echo "arm64" || echo "amd64")
export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-$ARCH"

# Set up pre-commit
pre-commit install

activate-jit-role () {
    SUBSCRIPTION_TYPE=${1:-"np"}
    REQUEST_GUID=$(python -c "import uuid; print(uuid.uuid4())")
    PRINCIPAL_ID=$(az ad signed-in-user show | jq -r .id)
    if [ $SUBSCRIPTION_TYPE == "np" ]; then
        SUBSCRIPTION_ID="bd2e96c1-fa09-4a7f-a6a1-4f1506acc156"
    else
        SUBSCRIPTION_ID="NOT_KNOWN"
    fi
    
    ROLE_NAME=${2:-"Contributor"}
    ROLE_DEFINITION_ID=$(az role definition list --name $ROLE_NAME | jq -r '.[0].name')
    JUSTIFICATION="IAC Development"
    DURATION="PT8H"
    REQUEST_BODY="{ \"properties\": { \"principalId\": \"$PRINCIPAL_ID\", \"roleDefinitionId\": \"/subscriptions/$SUBSCRIPTION_ID/providers/Microsoft.Authorization/roleDefinitions/$ROLE_DEFINITION_ID\", \"requestType\": \"SelfActivate\",\"justification\":\"$JUSTIFICATION\", \"scheduleInfo\": { \"startDateTime\": null, \"expiration\": { \"type\": \"AfterDuration\", \"endDateTime\": null, \"duration\": \"$DURATION\" } } } }"
    set -x
    az rest --method put \
    --url https://management.azure.com/providers/Microsoft.Subscription/subscriptions/$SUBSCRIPTION_ID/providers/Microsoft.Authorization/roleAssignmentScheduleRequests/$REQUEST_GUID?api-version=2020-10-01 \
    --body ''"$REQUEST_BODY"''
    set +x
}