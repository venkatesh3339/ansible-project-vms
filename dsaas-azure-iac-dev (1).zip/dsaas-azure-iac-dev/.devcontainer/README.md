# Overview
Refer: https://code.visualstudio.com/docs/devcontainers/containers

We are leveraging VS Code dev containers to simplify developer environment setup.

The idea is to start with an off the shelf image that is a close match and installing dependencies. Note that we are only choosing to install dependencies that change **infrequently** like, Azure CLI, Terraform, VS Code extensions etc.

Due to issue, [Support ${localWorkspaceFolder} when cloning in volume](https://github.com/microsoft/vscode-remote-release/issues/6160) we are following specific workaround from https://github.com/microsoft/vscode-remote-release/issues/6160#issuecomment-1025220161

Dev container configuration here is derived from template at https://github.com/OptumInsight-Analytics/dx-devcontainers-templates/tree/main/src/infra-aws

# Prerequisites
1. [Mac Only] Self Service --> AdminAccess and enable it as needed.
1. Install [VS Code](https://code.visualstudio.com/)
1. Install the [Dev Containers extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers)
1. [Mac Only] xcode-select --install (May have to re-run after major OS upgrade)
1. Install [Docker Desktop](https://www.docker.com/products/docker-desktop/)
    - Business Justification for AppStore request:
    
        I am DevOps engineer on Blue platform US team responsible for developing infrastructure as code. The Blue Platform aims to create a federated data architecture that pulls together strategic data from across UHG into a unified governance structure. My team is using Visual Studio Code Dev Containers to manage developer setup for multiple GitHub repositories. To be able to contribute to these repositories I need Docker Desktop for MAC so I can create dev containers for use with VS Code. At this point, the team has not been able to evaluate alternatives to Docker Desktop.
    - Update registry mirror. You can either do it through UI via Settings-->Docker Engine or by editing file at ~/.docker/daemon.json to add following.
        ```
        "registry-mirrors": [
            "https://docker.repo1.uhc.com"
        ]
        ```

# Setup
## Manual changes to Dev Containers extension
> **_IMPORTANT:_** Repeat after each update of **Dev Containers** extension

1. Compare and overwrite following files in dev container extension with contents from corresponding files under [resources](resources)
    `/Users/<MS_ID>/.vscode/extensions/ms-vscode-remote.remote-containers-<version>/scripts/bootstrap.Dockerfile`
    `/Users/<MS_ID>/.vscode/extensions/ms-vscode-remote.remote-containers-<version>/scripts/inspect-volume/volume.Dockerfile`
1. Note that our updates may not be accurate as and when extension is updated so pay close attention to the changes.
1. Quit all VS Code windows and reopen
1. You may sometimes notice that updating files at above locations may not take effect since by then VS Code has already created copies of files at path that looks like `/var/folders/2n/6wwv06cx09d37g49k3p7lykh0000gq/T/vsch`. In that case, just delete the current version folder under `var/folders/<random>/vsch/bootstrap-image and var/folders/<random>/vsch/inspect-volume folders`.

## Clone Repository
    
### Option 1: Clone in container volume

1. In VS Code, navigate to Top Menu-->View-->Command Palette-->"Dev Containers: Clone Repository in Named Container Volume"
1. Select **Clone a repository from Github in a Container Volume**
1. Search for the repo, `OptumInsight-Analytics/dsaas-azure-iac`
1. Select **branch**: `dev`
1. For **volume** it may be a good idea to use single volume for all repositories which will make it slightly easy to copy/paste files/contents between repositories. I use default name, `vsc-remote-containers`.
1. Leave the **target folder** name as-is on next prompt unless you happen to have another clone with the same name. In that case, you would want to edit it to be unique.
1. Wait for VS Code to finish cloning and it will automatically start dev container. It may take a while first time since the image will have to be built from scratch. Expect the build to fail since we need to go through remaining steps.

### Option 2: Clone in folder on host machine
This assumes that you have already cloned repository in a local folder (e.g. `~/src/<repo-name>`).
1. Open the folder in VS Code and ignore prompt for **Reopen in Container**.

## .env file
1. Create new file with name **.env** under [**.devcontainer**](./) folder. Note that this file is being ignored by git.
1. Add following lines to it and follow subsequent steps to set values. 
    ```
    USER=
    localWorkspaceFolder=
    ```
1. Enter your MS_ID for USER. This will match with the name of your user folder on host machine.
1. For `localWorkspaceFolder`, you need to enter one of following. Make sure you update the placeholders.
    - If you are using repository cloned in container volume then set as, `/var/lib/docker/volumes/<container_volume_name>/_data/<repo_name>`
    - If you are using repository cloned in local folder then set as absolute path of the local folder. e.g. `/Users/<ms_id>/src/<repo_name>`

## Create ~/.GITHUB_TOKEN
1. Create a new Personal Access Token(PAT) for Github. [Help](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-personal-access-token-classic)
1. For permissions, select all for `repo` and under `admin:org` select `read:org`
1. Copy the value of token once generated.
1. Click on `Configure SSO` and authorize it for `OptumInsight-Analytics` organization.
1. Save the newly generated token to `.GITHUB_TOKEN` file under your home(`/Users/<MS_ID>`) directory
1. Change permissions on the file to make sure only you have access to it. E.g. `chmod 600 ~/.GITHUB_TOKEN`

## Build dev container
1. Either click on **Reopen in Container** if prompted or navigate to Top Menu-->View-->Command Palette-->Dev Containers: Rebuild and Reopen in Container
1. It will take some time for image to be built the first time
1. Open new terminal if not already open. The terminal will be automatically launched in the container.
1. When using repository cloned in volume you will have to trust workspace in VS Code UI for source control to start working. You can update your ~/.gitconfig on host machine to mark it as safe with following example.
    ```
    [safe]
        directory = /workspaces/<repo_name>
    ```

# Known Issues
1. This setup has been tested only on Apple Silicon MAC. We will likely need to make changes for this to work on Intel MAC and Windows.
1. We are trying to leverage decent amount of caching in docker build which can lead to disk space maxing out for Docker Desktop. You can run cleanup commands for docker to reclaim space.
1. We also leverage a shared volume named "shared" as a shared cache for things like terraform provider plugins, tflint plugins, pip, pipenv etc that can be used for multiple containers for different projects. The volume can grow out of control and you may need to clean up stale versions of tools or you can just delete the volume altogether and it will be re-created on subsequent container startup with somewhat slower initialization of corresponding tools.
