# dsaas-azure-iac
DSaaS infrastructure as code repository
